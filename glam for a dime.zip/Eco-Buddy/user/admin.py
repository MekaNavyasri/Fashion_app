from django.contrib import admin
from .models import Profile, Shop , History
# Register your models here.

admin.site.register(Profile)
admin.site.register(Shop)
admin.site.register(History)